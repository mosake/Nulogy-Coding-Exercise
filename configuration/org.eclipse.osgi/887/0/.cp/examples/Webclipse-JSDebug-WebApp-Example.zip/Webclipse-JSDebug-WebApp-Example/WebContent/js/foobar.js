//1. I hope you came here by using the Loaded JavaScript view, 
//   if not give it a look.  
//2. Anyway, just change "#" to "." below, save the file, 
//   reload the page and you're done :)
$("#inspectorSection").toggle();